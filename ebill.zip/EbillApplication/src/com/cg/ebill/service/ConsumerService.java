package com.cg.ebill.service;

import java.util.List;

import com.cg.ebill.dto.Bill;
import com.cg.ebill.exception.EbillException;

public interface ConsumerService {

	public abstract List<Bill> searchBill(int ID) throws EbillException;
	
	public void insertBill(Bill bill) throws EbillException;

}