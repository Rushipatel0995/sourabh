package com.capgemini.service;

import com.capgemini.dao.EBillDAOImpl;
import com.capgemini.dao.IEBillDAO;
import com.capgemini.dto.BillDTO;
import com.capgemini.exception.BillUserException;

public class EBillServiceImpl implements IEBillService {
	private IEBillDAO eBillDAO;
	
	public EBillServiceImpl() {
		super();
		eBillDAO=new EBillDAOImpl();
	}

	@Override
	public String insert(BillDTO billDTO) throws BillUserException {
		String name =null;
		boolean isInserted=eBillDAO.insert(billDTO);
		
		if(isInserted)
		{
			name=eBillDAO.getConsName(billDTO.getConsumerNum());
		}
		else
		{
			throw new BillUserException("Record couldn't be inserted");
		}
		return name;
	}

}
