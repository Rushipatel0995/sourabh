package com.capgemini.dao;

public interface IQueryMapperEB {
	
	public static final String INSERT_BILL = "INSERT INTO billdetails VALUES(seq_bill_num.NEXTVAL,?,?,?,?,SYSDATE)";
	
	public static final String GET_CONSUMER = "SELECT consumer_name from consumers where consumer_num=?";
	
}
