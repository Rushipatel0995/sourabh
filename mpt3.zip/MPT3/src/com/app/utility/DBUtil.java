//Database utility class to connect to the DATASOURCE
package com.app.utility;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil {
private static Connection connection=null;
public static Connection getConnection() {
	try {
		InitialContext ctx=new InitialContext();
		DataSource dataSource=null;
		dataSource=(DataSource) ctx.lookup("java:/OracleDS");
		connection=dataSource.getConnection();
	} catch (NamingException e) {
		e.printStackTrace();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return connection;
}
}
