package com.app.service;

import com.app.dto.FirmMaster;
//The service interface with business logic and all the methods
public interface IRegisterService {
public boolean addRecord(FirmMaster firm);
public boolean updateRecord(String email);
}
