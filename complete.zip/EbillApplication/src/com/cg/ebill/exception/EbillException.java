package com.cg.ebill.exception;

@SuppressWarnings("serial")
public class EbillException extends Exception{
	public EbillException(String message){
		super();
	}

}
