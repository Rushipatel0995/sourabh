package com.java.cg.msms.ctrl;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.java.cg.msms.dto.TraineeBean;
import com.java.cg.msms.service.ModuleService;
import com.java.cg.msms.service.ModuleServiceImpl;

@WebServlet("/ModuleController")
public class ModuleController extends HttpServlet {
	private static final long serialVersionUID = 1L;
      ModuleService moduleService=null;
    public ModuleController() {
    	
    	moduleService=new ModuleServiceImpl();
    }
    private int getgrade(int no) {
		int grade=0;
		if(no<50)
			grade=0;
		else if(no>50 && no<60)
			grade=1;
		else if(no>60 && no<70)
			grade=2;
		else if(no>70 && no<80)
			grade=3;
		else if(no>80 && no<90)
			grade=4;
		else if(no>90)
			grade=5;
		return grade;
	}

	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	public void destroy() {
		// TODO Auto-generated method stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(request, response);
	}

	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String action=request.getParameter("action");
		
		if(action!=null)
		{
			try {
				if(action.equalsIgnoreCase("addDetails"))
				{
					ArrayList<Integer> id=moduleService.getId();
					request.setAttribute("ID", id);
					request.getRequestDispatcher("Pages/AddAssessment.jsp").forward(request, response);
					
				}
				if(action.equalsIgnoreCase("insertValues"))
				{
					int id=Integer.parseInt(request.getParameter("id"));
					String name=request.getParameter("name");
					int mtt_no=Integer.parseInt(request.getParameter("mtt"));
					int mpt_no=Integer.parseInt(request.getParameter("mpt"));
					int ass_marks=Integer.parseInt(request.getParameter("asg"));
					float mt_no=(float) (mtt_no*0.15);
					float mp_no=(float) (mpt_no*0.7);
					float as_no=(float) (ass_marks*0.15);
					int total_no=((int) (mt_no+mp_no+as_no));
					int grade=getgrade(total_no);
					TraineeBean bean=new TraineeBean(id,name,mpt_no, mtt_no,ass_marks,total_no,grade);
					moduleService.addDetails(bean);
						TraineeBean traineeBean=moduleService.viewDetails(id);
						request.setAttribute("traineeBean",traineeBean);
						request.getRequestDispatcher("Pages/ModuleScore.jsp").forward(request, response);		
					
				
				}
				
				
			}
			catch (Exception e) {
			}
		}
		
		
		
	
	}

	
}
