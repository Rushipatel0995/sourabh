package com.java.cg.msms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.java.cg.msms.dto.TraineeBean;
import com.java.cg.msms.exception.TraineeException;
import com.java.cg.msms.util.DBUtil;
public class ModuleDAOImpl implements ModuleDAO {
	/*
	 * Author:Sandeep Sen
	 * Emp_Id:137608
	 * Date	 :07-11-2017 
	 * Description:Add details;
	 * 
	 */
	@Override
	public int addDetails(TraineeBean bean) throws TraineeException {

		int id = 0;
		try (Connection connection = DBUtil.getConnection()) {
			System.out.println(connection);
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into AssessmentScore values(?,?,?,?,?,?,?)");
			preparedStatement.setInt(1, bean.getId());
			preparedStatement.setString(2, bean.getModule_name());
			preparedStatement.setInt(3, bean.getMpt_no());
			preparedStatement.setInt(4, bean.getMtt_no());
			preparedStatement.setInt(5, bean.getAss_marks());
			preparedStatement.setInt(6, bean.getTotal_no());
			preparedStatement.setInt(7, bean.getGrade());
			preparedStatement.executeQuery();
		} catch (Exception e) {

		}
		return id;
	}
	/*
	 * Author:Sandeep Sen
	 * Emp_Id:137608
	 * Date	 :07-11-2017 
	 * Description:View details;
	 * 
	 */
	@Override
	public TraineeBean viewDetails(int id) throws TraineeException {

		TraineeBean traineeBean = null;
		try (Connection connection = DBUtil.getConnection()) {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from AssessmentScore where trainee_id=?");
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			resultSet.next();
			traineeBean = new TraineeBean(resultSet.getInt(1), resultSet.getString(2), resultSet.getInt(3),
					resultSet.getInt(4), resultSet.getInt(5), resultSet.getInt(6), resultSet.getInt(7));

		} catch (Exception e) {

		}

		return traineeBean;
	}
	/*
	 * Author:Sandeep Sen
	 * Emp_Id:137608
	 * Date	 :07-11-2017 
	 * Description:All details;
	 * 
	 */
	@Override
	public ArrayList<Integer> getId() {
		ArrayList<Integer> values = null;
		try (Connection connection = DBUtil.getConnection()) {
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("select trainee_id from trainees");
			values = new ArrayList<>();
			while (resultSet.next()) {
				int val = resultSet.getInt(1);
				values.add(val);
			}

		} catch (Exception e) {

		}
		return values;
	}
}
