CREATE TABLE trainees(trainee_id number primary key, trainee_name varchar2(30));
INSERT INTO trainees VALUES(898983,'Tina');
INSERT INTO trainees VALUES(898984,'Vina');
INSERT INTO trainees VALUES(898985,'Gita');
INSERT INTO trainees VALUES(898986,'Rita');
INSERT INTO trainees VALUES(898987,'Sita');
INSERT INTO trainees VALUES(898988,'Mala');

CREATE TABLE AssessmentScore(trainee_id number references trainees(trainee_id), module_name varchar2(10), mpt number, mtt number, ass_marks number, total number,
grade number);
