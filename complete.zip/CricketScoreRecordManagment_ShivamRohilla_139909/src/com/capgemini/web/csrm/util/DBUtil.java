package com.capgemini.web.csrm.util;

import java.sql.*;

import javax.naming.*;
import javax.sql.DataSource;

public class DBUtil {
	/**
	 * @return
	 * @throws NamingException
	 * @throws SQLException
	 */
	public static Connection getConnection() throws NamingException, SQLException{
		InitialContext context = new InitialContext();
		DataSource dbSource=(DataSource)context.lookup("java:/OracleDS");
		Connection connection=dbSource.getConnection();
		return connection;
	}
}
