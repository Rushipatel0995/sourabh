package com.app.dto;
/*Name          Null?    Type          
------------- -------- ------------- 
FIRM_ID       NOT NULL NUMBER(8)     
OWNER_NAME             VARCHAR2(100) 
BUSINESS_NAME          VARCHAR2(100) 
EMAIL                  VARCHAR2(80)  
MOBILE_NO              VARCHAR2(10)  
ISACTIVE               CHAR(1)       */
public class FirmMaster {
	/*The POJO Class With all the getters and setters*/
private int firmId;
private String ownerFirstName;
private String ownerMiddleName;
private String ownerLastName;
private String businessName;
private String email;
public int getFirmId() {
	return firmId;
}
public void setFirmId(int firmId) {
	this.firmId = firmId;
}
//Constructor from the field
public FirmMaster(int firmId, String ownerFirstName, String ownerMiddleName,
		String ownerLastName, String businessName, String email,
		String mobileNo, char isActive) {
	super();
	this.firmId = firmId;
	this.ownerFirstName = ownerFirstName;
	this.ownerMiddleName = ownerMiddleName;
	this.ownerLastName = ownerLastName;
	this.businessName = businessName;
	this.email = email;
	this.mobileNo = mobileNo;
	this.isActive = isActive;
}
public String getBusinessName() {
	return businessName;
}
public void setBusinessName(String businessName) {
	this.businessName = businessName;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
public char getIsActive() {
	return isActive;
}
public void setIsActive(char isActive) {
	this.isActive = isActive;
}
private String mobileNo;
private char isActive;
public FirmMaster() {
	super();
}
public String getOwnerLastName() {
	return ownerLastName;
}
public void setOwnerLastName(String ownerLastName) {
	this.ownerLastName = ownerLastName;
}
public String getOwnerMiddleName() {
	return ownerMiddleName;
}
public void setOwnerMiddleName(String ownerMiddleName) {
	this.ownerMiddleName = ownerMiddleName;
}
public String getOwnerFirstName() {
	return ownerFirstName;
}
public void setOwnerFirstName(String ownerFirstName) {
	this.ownerFirstName = ownerFirstName;
}
}
