CREATE TABLE DVD(
dvd_id NUMBER(12) PRIMARY KEY ,
dvd_name  VARCHAR2(50), 
no_of_copies NUMBER (10) , 
type_of_dvd VARCHAR2 (10) CHECK(type_of_dvd IN('Video','Audio')), 
price NUMBER (20,3));
           
INSERT INTO DVD VALUES(111,'3 Idiots',5,'Video',250);
           
         
INSERT INTO DVD VALUES (222,'Don',2, 'Video',150);
         
INSERT INTO DVD VALUES (333,'Nakshaktrache Lene',4,'Audio',100);

CREATE  TABLE  CustomerDvdDetails(
user_name VARCHAR2(50) ,
dvd_id NUMBER(12) REFERENCES DVD(dvd_id),
dvd_issue_date DATE ,dvd_return_date DATE ,
deposit NUMBER(20,3));

