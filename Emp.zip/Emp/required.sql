CREATE TABLE empl (empid NUMBER PRIMARY KEY, ename VARCHAR2 (20), salary NUMBER(10,2),dept NUMBER,designation VARCHAR2(20));

INSERT INTO empl VALUES(1001,'Sourabh',80000,20,'Analyst');
INSERT INTO empl VALUES(1002,'Avijit',50000,30,'Analyst');
INSERT INTO empl VALUES(1003,'Rushi',90000,10,'Developer');


CREATE SEQUENCE empl_sequence
START WITH 1;
