package com.capgemini.employee.dao;

public class QueryMapperEmployee {
	
	public static final String INSERT_EMP = "INSERT INTO empl VALUES(empl_sequence.NEXTVAL,?,?,?,?)";
	
	public static final String DELETE_EMP = "DELETE FROM empl WHERE empid=?";
	
	public static final String UPDATE_EMP = "UPDATE empl SET SALARY = ?  WHERE empid=?";
	
	public static final String VIEWALL_EMP = "SELECT empid, ename, salary,dept,designation FROM empl ";
	
	public static final String SEARCH_EMP = "SELECT empid, ename, salary,dept,designation FROM empl WHERE empid=?";
	

}
