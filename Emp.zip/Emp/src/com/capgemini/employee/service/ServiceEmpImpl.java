package com.capgemini.employee.service;

import java.util.List;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.dao.EmpDAOImpl;
import com.capgemini.employee.dao.IEmpDAO;
import com.capgemini.employee.exception.EmployeeException;

public class ServiceEmpImpl implements IServiceEmp {
	
	IEmpDAO empDAO = new EmpDAOImpl();
	
	@Override
	public boolean updateSal(int empid, int salary) throws EmployeeException {
		IEmpDAO empDAO = new EmpDAOImpl();

		boolean isUpdated = empDAO.updateSal(empid,salary);
		return (isUpdated);
	}

	@Override
	public List<EmployeeBean> viewAll() throws EmployeeException {
		List<EmployeeBean> empList = empDAO.viewAll();
		return empList;
	}

	@Override
	public boolean deleteEmp(int empid) throws EmployeeException {
		IEmpDAO empDAO = new EmpDAOImpl();

		boolean isDeleted = empDAO.deleteEmp(empid);
		return (isDeleted);
	}

	@Override
	public List<EmployeeBean> search(int empid) throws EmployeeException {
		List<EmployeeBean> empList = empDAO.search(empid);
		return empList;
	}

	@Override
	public boolean insertEmp(EmployeeBean employeeBean)
			throws EmployeeException {
		boolean isItInserted = false;

		
		IEmpDAO empDAO = new EmpDAOImpl();
		
		isItInserted=empDAO.insertEmp(employeeBean);
		return isItInserted; 
		
	
	}

}
