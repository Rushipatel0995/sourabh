package com.capgemini.employee.pi;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeeException;
import com.capgemini.employee.service.IServiceEmp;
import com.capgemini.employee.service.ServiceEmpImpl;

public class EmpMain {

	static Scanner sc = new Scanner(System.in);
	static IServiceEmp empService = null;
	static ServiceEmpImpl ServiceEmpImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		EmployeeBean EmployeeBean = null;

		String empId = null;
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   ICARE CAPGEMINI TRUST ");
			System.out.println("_______________________________\n");

			System.out.println("1.Add Donator ");
			System.out.println("2.View Donator");
			System.out.println("3.Retrive All");
			System.out.println("4.Retrive All");
			System.out.println("5.Retrive All");
			System.out.println("6.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (EmployeeBean == null) {
						EmployeeBean = populateEmployeeBean();
						// System.out.println(EmployeeBean);
					}

					try {
						empService = new ServiceEmpImpl();
						
						boolean empId = empService.insertEmp(EmployeeBean);

						System.out
								.println("Donator details  has been successfully registered ");
						System.out.println("Donator  ID Is: " + empId);

					} catch (EmployeeException donorException) {
						logger.error("exception occured", donorException);
						System.out.println("ERROR : "
								+ donorException.getMessage());
					} finally {
						empId = null;
						empService = null;
						EmployeeBean = null;
					}

					break;

				case 2:

					ServiceEmpImpl = new ServiceEmpImpl();

					System.out.println("Enter numeric donor id:");
					empId = sc.next();

					while (true) {
						if (ServiceEmpImpl.validateempId(empId)) {
							break;
						} else {
							System.err
									.println("Please enter numeric donor id only, try again");
							empId = sc.next();
						}
					}

					EmployeeBean = getDonorDetails(empId);

					if (EmployeeBean != null) {
						System.out.println("Name             :"
								+ EmployeeBean.getDonorName());
						System.out.println("Address          :"
								+ EmployeeBean.getAddress());
						System.out.println("Phone Number     :"
								+ EmployeeBean.getPhoneNumber());
						System.out.println("Donor Date       :"
								+ EmployeeBean.getDonationDate());
						System.out.println("Donation Amount  :"
								+ EmployeeBean.getDonationAmount());
					} else {
						System.err
								.println("There are no donation details associated with donor id "
										+ empId);
					}

					break;

				case 3:

					empService = new ServiceEmpImpl();
					try {
						List<EmployeeBean> donorList = new ArrayList<EmployeeBean>();
						donorList = empService.retriveAll();

						if (donorList != null) {
							Iterator<EmployeeBean> i = donorList.iterator();
							while (i.hasNext()) {
								System.out.println(i.next());
							}
						} else {
							System.out
									.println("Nobody has made a donation, yet.");
						}

					}

					catch (EmployeeException e) {

						System.out.println("Error  :" + e.getMessage());
					}

					break;

				case 4:

					System.out.print("Exit Trust Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
	}// end of try

	/*
	 * This function will call the service layer method and return the bean
	 * object which is populated by the information of the given empId in
	 * parameter
	 */
	private static EmployeeBean getDonorDetails(String empId) {
		EmployeeBean EmployeeBean = null;
		empService = new ServiceEmpImpl();

		try {
			EmployeeBean = empService.search(empId);
		} catch (EmployeeException donarException) {
			logger.error("exception occured ", donarException);
			System.out.println("ERROR : " + donarException.getMessage());
		}

		empService = null;
		return EmployeeBean;
	}

	/*
	 * This function will be called by main and will return a validated bean
	 * object OR null if details are invalid
	 */
	private static EmployeeBean populateEmployeeBean() {

		// Reading and setting the values for the EmployeeBean
		
		EmployeeBean EmployeeBean = new EmployeeBean();;

		System.out.println("\n Enter Details");

		System.out.println("Enter donor name: ");
		EmployeeBean.setDonorName(sc.next());

		System.out.println("Enter donor contact: ");
		EmployeeBean.setPhoneNumber(sc.next());

		System.out.println("Enter donor address: ");
		EmployeeBean.setAddress(sc.next());

		System.out.println("Enter donation amount: ");

		try {
			EmployeeBean.setDonationAmount(sc.nextFloat());
		} catch (InputMismatchException inputMismatchException) {
			sc.nextLine();
			System.err
					.println("Please enter a numeric value for donation amount, try again");
			}

		ServiceEmpImpl = new ServiceEmpImpl();

		try {
			ServiceEmpImpl.validateDonor(EmployeeBean);
			return EmployeeBean;
		} catch (EmployeeException donorException) {
			logger.error("exception occured", donorException);
			System.err.println("Invalid data:");
			System.err.println(donorException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}
